#pragma once
#include <app/common.hpp>
#include <widget/Widget.hpp>


namespace rack {
namespace app {


PRIVATE widget::Widget* createMenuBar();


} // namespace app
} // namespace rack
