#pragma once
#include <app/common.hpp>
#include <widget/Widget.hpp>


namespace rack {
namespace app {


PRIVATE widget::Widget* tipWindowCreate();


} // namespace app
} // namespace rack
