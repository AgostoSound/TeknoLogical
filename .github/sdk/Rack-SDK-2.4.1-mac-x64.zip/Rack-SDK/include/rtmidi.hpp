#pragma once
#include <common.hpp>


namespace rack {


PRIVATE void rtmidiInit();


} // namespace rack
