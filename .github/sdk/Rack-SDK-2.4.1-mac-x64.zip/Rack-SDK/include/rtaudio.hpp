#pragma once
#include <common.hpp>


namespace rack {


PRIVATE void rtaudioInit();


} // namespace rack
