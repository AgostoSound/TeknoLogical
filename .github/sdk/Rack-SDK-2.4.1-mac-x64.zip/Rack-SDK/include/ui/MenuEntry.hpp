#pragma once
#include <widget/OpaqueWidget.hpp>
#include <ui/common.hpp>


namespace rack {
namespace ui {


struct MenuEntry : widget::OpaqueWidget {
	MenuEntry();
};


} // namespace ui
} // namespace rack
