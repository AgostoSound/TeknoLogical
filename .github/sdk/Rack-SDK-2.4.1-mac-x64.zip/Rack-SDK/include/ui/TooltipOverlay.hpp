#pragma once
#include <widget/TransparentWidget.hpp>
#include <ui/common.hpp>


namespace rack {
namespace ui {


struct TooltipOverlay : widget::TransparentWidget {
};


} // namespace ui
} // namespace rack
